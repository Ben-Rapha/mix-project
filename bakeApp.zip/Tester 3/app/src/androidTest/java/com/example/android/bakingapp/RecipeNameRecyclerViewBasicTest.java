package com.example.android.bakingapp;

import android.support.test.espresso.contrib.RecyclerViewActions;
import android.support.test.espresso.intent.Intents;
import android.support.test.runner.AndroidJUnit4;
import android.support.test.rule.ActivityTestRule;
import com.example.android.bakingapp.UI.MainActivity;
import com.example.android.bakingapp.UI.RecipeDisplay;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.intent.Intents.intended;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasExtraWithKey;
import static android.support.test.espresso.matcher.ViewMatchers.hasDescendant;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.core.AllOf.allOf;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class RecipeNameRecyclerViewBasicTest {

    @Rule public ActivityTestRule<MainActivity> mActivityTestRule =
            new ActivityTestRule<>(MainActivity.class);


    @Test
    public void scrollRecyclerView_verifyData(){
        //first check if the recyclerView for displaying recipe names is displayed
        onView((withId(R.id.recycler_view_recipe))).check(matches(isDisplayed()));

        //check if the recyclerView contains  one recipe name
        onView((withId(R.id.recycler_view_recipe)))
                .check(matches(hasDescendant(withText("NUTELLA PIE"))));

        //  check if  on click  on ingredient textVie it displays ingredient list
        onView((withId(R.id.recycler_view_recipe)))
                .perform(RecyclerViewActions.actionOnItemAtPosition(2,click()));
        onView(withText(R.string.ingredients)).check(matches(isDisplayed()))
        .perform(click());
        onView(withId(R.id.ingredient_list_recycler_view)).check(matches(isDisplayed()));
    }

    @Test
    public void checkForRightIntentLunched(){

        Intents.init();

        // check if the intent being sent contains the right key
        onView((withId(R.id.recycler_view_recipe)))
                .perform(RecyclerViewActions.actionOnItemAtPosition(3,click()));
        intended(allOf(
                hasComponent(RecipeDisplay.class.getName()),
                hasExtraWithKey(RecipeDisplay.BAKE_ID)
        ));
        Intents.release();
    }
}

