package com.example.android.bakingapp.Model;

import android.graphics.Movie;
import android.os.Parcel;
import android.os.Parcelable;

public class Ingredients implements Parcelable {

    private String mMeasure;
    private String mQuantity;
    private String mIngredient;

    public Ingredients(String quantity , String measure ,String ingredient){
        this.mQuantity = quantity;
        this.mMeasure = measure;
        this.mIngredient = ingredient;
    }

    public String getmMeasure() {
        return mMeasure;
    }

    public void setmMeasure(String mMeasure) {
        this.mMeasure = mMeasure;
    }

    public String getMquantity() {
        return mQuantity;
    }

    public void setMquantity(String mquantity) {
        this.mQuantity = mquantity;
    }

    public String getmIngredient() {
        return mIngredient;
    }

    public void setmIngredient(String mIngredient) {
        this.mIngredient = mIngredient;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mIngredient);
        parcel.writeString(this.mMeasure);
        parcel.writeString(this.mQuantity);

    }
    private Ingredients(Parcel in){
        this.mIngredient = in.readString();
        this.mMeasure = in.readString();
        this.mQuantity = in.readString();
    }

    public static final Parcelable.Creator<Ingredients> CREATOR = new Parcelable.Creator<Ingredients>(){

        @Override
        public Ingredients createFromParcel(Parcel parcel) {
            return  new Ingredients(parcel);
        }

        @Override
        public Ingredients[] newArray(int i) {
            return new Ingredients[i];
        }
    };
}

