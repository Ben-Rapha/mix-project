package com.example.android.bakingapp.UI;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.android.bakingapp.Adapters.BakeAdapter;
import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.R;
import com.example.android.bakingapp.Repository.BakeViewModel.BakeViewModel;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecipeNameFragment extends Fragment{
    private BakeViewModel bakeViewModel;
    public static List<Bake>  bakeListBag = new ArrayList<>();

    @BindView(R.id.recycler_view_recipe)
    RecyclerView recyclerView;

    BakeAdapter bakeAdapter;
    Bake adapterBake;
    LinearLayoutManager layoutManager;
    Bake temp;

    private onItemSelectedListener listener;

    public interface onItemSelectedListener{
        void onSelectItem(Bake bake);
    }

    public RecipeNameFragment(){ }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View viewRoot = inflater.inflate(R.layout.recipe_fragement,container,false);
        ButterKnife.bind(this,viewRoot);
        bakeViewModel = ViewModelProviders.of(this).get(BakeViewModel.class);
        if (savedInstanceState != null){
            bakeListBag = savedInstanceState.getParcelableArrayList(getString(R.string.bake_list));
        } else {
            bakeViewModel.getBakeData();
            notifyObserver();
        }
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        bakeAdapter = new BakeAdapter(getContext(), bakeListBag);
        bakeAdapter.setOnItemClickLister(new BakeAdapter.OnItemClickLister() {
            @Override
            public void onClickedItem(Bake bake) {
                adapterBake = bake;
                listener.onSelectItem(bake);
            }
        });
        recyclerView.setAdapter(bakeAdapter);
        return viewRoot;
    }

    private void notifyObserver() {
        bakeViewModel.getDataFromViewModel().observe(this, new Observer<List<Bake>>() {
            @Override
            public void onChanged(@Nullable List<Bake> bakes) {
                bakeListBag = bakes;
                bakeAdapter.updateBakeAdapter(bakes);
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof onItemSelectedListener){
            listener = (onItemSelectedListener) context;
        } else {
            throw new ClassCastException("must implement onItemSelectedListener");
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.bake_list), (ArrayList<? extends Parcelable>) bakeListBag);
    }

}
