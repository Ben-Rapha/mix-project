package com.example.android.bakingapp.Model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "bake_database", indices = {@Index(value = {"bakeName"},unique = true)})
public class Bake implements Parcelable {

    @ColumnInfo(name = "id")
    private String mId;
    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "bakeName")
    private String mName;
    @ColumnInfo(name = "image")
    private String mImage;
    @ColumnInfo(name = "serving")
    private String mServing;

    private List<Ingredients> mIngredientsBag;

    private List<Steps> mStepsBag;

    public Bake(String mId, String mName, List<Ingredients> mIngredientsBag , List<Steps> mStepsBag,
                String mServing , String mImage  ){
        this.mId = mId;
        this.mName = mName;
        this.mIngredientsBag = mIngredientsBag;
        this.mStepsBag = mStepsBag;
        this.mServing = mServing;
        this.mImage = mImage;
    }

    public String getId() {
        return mId;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }

    public String getImage() {
        return mImage;
    }

    public void setImage(String mImage) {
        this.mImage = mImage;
    }

    public String getServing() {
        return mServing;
    }

    public void setServing(String mServing) {
        this.mServing = mServing;
    }

    public List<Ingredients> getIngredientsBag() {
        return mIngredientsBag;
    }

    public void setIngredientsBag(List<Ingredients> mIngredientsBag) {
        this.mIngredientsBag = mIngredientsBag;
    }

    public List<Steps> getStepsBag() {
        return mStepsBag;
    }

    public void setStepsBag(List<Steps> mStepsBag) {
        this.mStepsBag = mStepsBag;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mId);
        parcel.writeString(this.mImage);
        parcel.writeString(this.mName);
        parcel.writeString(this.mServing);
        parcel.writeTypedList(this.mIngredientsBag);
        parcel.writeTypedList(this.mStepsBag);
    }

    private Bake(Parcel in){
        this.mId = in.readString();
        this.mImage = in.readString();
        this.mName= in.readString();
        this.mServing= in.readString();
        mIngredientsBag = new ArrayList<>();
         in.readTypedList(mIngredientsBag,Ingredients.CREATOR);
        mStepsBag = new ArrayList<>();
         in.readTypedList(mStepsBag, Steps.CREATOR);
    }
    public static final Parcelable.Creator<Bake> CREATOR = new Parcelable.Creator<Bake>(){

        @Override
        public Bake createFromParcel(Parcel parcel) {
            return  new Bake(parcel);
        }

        @Override
        public Bake[] newArray(int i) {
            return new Bake[i];
        }
    };
}
