package com.example.android.bakingapp.Repository;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverter;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;

import com.example.android.bakingapp.Model.Bake;

@TypeConverters({Convertor.class})
@Database(entities = {Bake.class}, version = 1,exportSchema = false)
public abstract class BakeRoomDatabase extends RoomDatabase{

    public abstract BakeDao bakeDao();

    private static  BakeRoomDatabase INSTANCE;


    public static BakeRoomDatabase getDatabase(final Context context){
        if (INSTANCE == null){
            synchronized (BakeRoomDatabase.class){
                if (INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            BakeRoomDatabase.class,"bake_database").build();
                }
            }
        }
        return INSTANCE;
    }
}

