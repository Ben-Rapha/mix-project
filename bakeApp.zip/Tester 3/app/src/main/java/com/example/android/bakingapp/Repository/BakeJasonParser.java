package com.example.android.bakingapp.Repository;

import android.util.Log;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.Model.Steps;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BakeJasonParser {


    public static List<Bake> parseBakeJson(String Json){
        List<Bake> bakeBagListArray = new ArrayList<>();
        try {
            JSONArray jsonArray  = new JSONArray(Json);
            for(int k = 0 ; k < jsonArray.length(); k++) {
                JSONObject bakeObject = jsonArray.getJSONObject(k);
                String id = bakeObject.optString(BakeKeys.getID());
                String name = bakeObject.optString(BakeKeys.getNAME());
                String image = bakeObject.optString(BakeKeys.getIMAGE());
                String servings = bakeObject.optString(BakeKeys.getSERVINGS());
                JSONArray ingredientArray = bakeObject.getJSONArray(BakeKeys.getINGREDIENTS());
                ArrayList<Ingredients> ingredientsBagArray = new ArrayList<>();
                for (int i = 0; i < ingredientArray.length(); i++) {
                    JSONObject ingredientsObject = ingredientArray.getJSONObject(i);
                    String quantity = ingredientsObject.optString(BakeKeys.getQUANTITY());
                    String measure = ingredientsObject.optString(BakeKeys.getMEASURE());
                    String ingredient = ingredientsObject.optString(BakeKeys.getINGREDIENT());
                    ingredientsBagArray.add(new Ingredients(quantity, measure, ingredient));
                }
                List<Steps> stepsBagArray = new ArrayList<>();
                JSONArray stepsArray = bakeObject.getJSONArray(BakeKeys.getSTEPS());
                for (int p = 0; p < stepsArray.length(); p++) {
                    JSONObject stepsObject = stepsArray.getJSONObject(p);
                    String stepsID = stepsObject.optString(BakeKeys.getID());
                    String shortDescription = stepsObject.optString(BakeKeys.getStepsShortDescription());
                    String description = stepsObject.optString(BakeKeys.getStepsDescription());
                    String videoURl = stepsObject.optString(BakeKeys.getStepsVideoUrl());
                    String thumbnailUrl = stepsObject.optString(BakeKeys.getStepsThubnailUrl());
                    stepsBagArray.add(new Steps(stepsID, shortDescription, description, videoURl, thumbnailUrl));
                }
                bakeBagListArray.add(new Bake(id, name, ingredientsBagArray, stepsBagArray, servings, image));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return bakeBagListArray;
    }
}
