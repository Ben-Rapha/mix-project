package com.example.android.bakingapp.Repository;

import android.arch.persistence.room.TypeConverter;

import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.Model.Steps;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.List;

public class Convertor {

    @TypeConverter
    public static String getStringFromArray(List<Ingredients> ingredients){
        Gson gson = new Gson();
        return gson.toJson(ingredients);
    }
    @TypeConverter
    public static List<Ingredients> getIngredientListFromString(String ingredient){
        Gson gson = new Gson();
        TypeToken<List<Ingredients>> listTypeToken = new TypeToken<List<Ingredients>>(){};
        return gson.fromJson(ingredient,listTypeToken.getType());
    }
    @TypeConverter
    public static String getStepListFromArray(List<Steps> steps ){
        Gson gson = new Gson();
        return gson.toJson(steps);
    }
    @TypeConverter
    public static List<Steps> getListFromString(String steps){
        Gson gson = new Gson();
        TypeToken<List<Steps>> listTypeToken = new TypeToken<List<Steps>>(){};
        return gson.fromJson(steps,listTypeToken.getType());
    }
}

