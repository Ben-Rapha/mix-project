package com.example.android.bakingapp.Repository;

public class BakeKeys {
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String INGREDIENTS = "ingredients";
    private static final String QUANTITY = "quantity";
    private static final String MEASURE = "measure";
    private static final String INGREDIENT = "ingredient";
    private static final String STEPS = "steps";
    private static final String STEPS_SHORT_DESCRIPTION = "shortDescription";
    private static final String STEPS_DESCRIPTION = "description";
    private static final String STEPS_VIDEO_URL = "videoURL";
    private static final String STEPS_THUBNAIL_URL = "thumbnailURL";
    private static final String SERVINGS = "servings";
    private static final String IMAGE = "image";

    public static String getID() {
        return ID;
    }

    public static String getNAME() {
        return NAME;
    }

    public static String getINGREDIENTS() {
        return INGREDIENTS;
    }

    public static String getQUANTITY() {
        return QUANTITY;
    }

    public static String getMEASURE() {
        return MEASURE;
    }

    public static String getINGREDIENT() {
        return INGREDIENT;
    }

    public static String getSTEPS() {
        return STEPS;
    }

    public static String getStepsShortDescription() {
        return STEPS_SHORT_DESCRIPTION;
    }

    public static String getStepsDescription() {
        return STEPS_DESCRIPTION;
    }

    public static String getStepsVideoUrl() {
        return STEPS_VIDEO_URL;
    }

    public static String getStepsThubnailUrl() {
        return STEPS_THUBNAIL_URL;
    }

    public static String getSERVINGS() {
        return SERVINGS;
    }

    public static String getIMAGE() {
        return IMAGE;
    }





}
