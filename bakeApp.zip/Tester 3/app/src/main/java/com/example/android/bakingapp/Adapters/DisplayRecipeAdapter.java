package com.example.android.bakingapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;
import com.example.android.bakingapp.UI.MainActivity;
import com.example.android.bakingapp.UI.RecipeDetail;
import com.example.android.bakingapp.UI.RecipeDisplay;

import java.util.ArrayList;
import java.util.List;

public class DisplayRecipeAdapter extends RecyclerView.Adapter<DisplayRecipeAdapter.ViewHolder> {
    private TextView recipeNameView;
    private Context context;
    static private List<Steps> bakeBag  = new ArrayList<>();

    private OnRecipeItemSelect onRecipeItemSelect;
    public interface OnRecipeItemSelect{
        void onItemSelect(Steps steps, int position,List<Steps> stepsList);
    }

    public void setOnRecipeItemSelect(OnRecipeItemSelect onRecipeItemSelect){
        this.onRecipeItemSelect = onRecipeItemSelect;
    }

    public DisplayRecipeAdapter(Context context, List<Steps> bakeBag){
        this.context = context;
        this.bakeBag = bakeBag;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ViewHolder(View itemView) {
            super(itemView);
            recipeNameView = itemView.findViewById(R.id.text_view_recipe_display);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onRecipeItemSelect.onItemSelect(bakeBag.get(getAdapterPosition()),getAdapterPosition(),bakeBag);
        }
    }
    @NonNull
    @Override
    public DisplayRecipeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View contentView = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.row_layout_to_display_recipes,parent,false);
        return new DisplayRecipeAdapter.ViewHolder(contentView);
    }

    @Override
    public void onBindViewHolder(@NonNull DisplayRecipeAdapter.ViewHolder holder, int position) {
        final int i = holder.getAdapterPosition();
        final Steps steps = bakeBag.get(i);
        recipeNameView.setText(steps.getmShortDescription());
    }

    public static List<Steps> sendStepBag(){
        if (bakeBag != null){
            return bakeBag;
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return bakeBag.size();
    }
}
