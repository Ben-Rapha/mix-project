package com.example.android.bakingapp.UI;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.R;

import java.util.List;


public class DisplayIngredientList extends AppCompatActivity implements
        DisplayRecipeFragment.OnIngredientClickListener {
    Bake bake;
    List<Ingredients> ingredientsList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ingredient_list);
        if (savedInstanceState == null){
            bake = getIntent().getParcelableExtra("BAKE");
            ingredientsList = bake.getIngredientsBag();
            IngredientsFragment.setIngredientBag(ingredientsList);
            FragmentManager recipeFragmentManager = getSupportFragmentManager();
            IngredientsFragment ingredientFragment = new IngredientsFragment();
            recipeFragmentManager.beginTransaction()
                    .add(R.id.ingredient_list_container, ingredientFragment)
                    .commit();
        }

    }

    @Override
    public void onIngredientClicked(Bake bake) {

    }


}
