package com.example.android.bakingapp.UI;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.android.bakingapp.Adapters.BakeAdapter;
import com.example.android.bakingapp.Adapters.DisplayRecipeAdapter;
import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;

import java.util.List;

public class MainActivity extends AppCompatActivity implements RecipeNameFragment.onItemSelectedListener,
        DisplayRecipeFragment.OnIngredientClickListener,DisplayRecipeFragment.OnRecipeDetailClickListener {

    List<Steps> steps;
    private boolean twoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            if (findViewById(R.id.master_layout) != null) {
                twoPane = true;
                if (savedInstanceState == null) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    RecipeNameFragment recipeNameFragment = new RecipeNameFragment();
                    fragmentManager.beginTransaction()
                            .add(R.id.recipe_container, recipeNameFragment)
                            .commit();
                }
            } else {
                twoPane = false;
                if (savedInstanceState == null){
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    RecipeNameFragment recipeNameFragment = new RecipeNameFragment();
                    fragmentManager.beginTransaction()
                            .add(R.id.recipe_container, recipeNameFragment)
                            .commit();
                }

            }

    }

    @Override
    public void onSelectItem(Bake bake) {
        if(twoPane){
            steps = bake.getStepsBag();
            FragmentManager fragmentManager = getSupportFragmentManager();
            DisplayRecipeFragment.setBake(bake);
            DisplayRecipeFragment.setStepsbag(steps);
            DisplayRecipeFragment displayRecipeFragment = new DisplayRecipeFragment();
            fragmentManager.beginTransaction()
                    .replace(R.id.recipe_display_container, displayRecipeFragment)
                    .commit();
        } else {
            Intent intent = new Intent(this, RecipeDisplay.class);
            intent.putExtra(RecipeDisplay.BAKE_ID,bake);
            startActivity(intent);
        }
    }

    @Override
    public void onIngredientClicked(Bake bake) {
        if(twoPane){
            IngredientsFragment.setIngredientBag(bake.getIngredientsBag());
            FragmentManager recipeFragmentManager = getSupportFragmentManager();
            IngredientsFragment ingredientFragment = new IngredientsFragment();
            recipeFragmentManager.beginTransaction()
                    .replace(R.id.recipe_display_container, ingredientFragment)
                    .commit();
        }
    }

    @Override
    public void onRecipeClicked(Steps steps, int position, List<Steps> stepsList) {
        if(twoPane){
            RecipeDetailFragment.setPosition(position);
            RecipeDetailFragment.getSetListBag(stepsList);
            RecipeDetailFragment.setStep(steps);
            FragmentManager fragmentManager = getSupportFragmentManager();
            RecipeDetailFragment recipeDetailFragment = new RecipeDetailFragment();
            fragmentManager.beginTransaction()
                    .replace(R.id.recipe_display_container,recipeDetailFragment)
                    .commit();
        }
    }
}
