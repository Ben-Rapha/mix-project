package com.example.android.bakingapp.Repository;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import com.example.android.bakingapp.Model.Bake;

import java.util.List;

@Dao
public interface BakeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Bake bake);

    @Query("SELECT * from bake_database ORDER BY bakeName ASC")
    LiveData<List<Bake>> getAllBake();

    @Query("SELECT * from bake_database ORDER BY bakeName ASC")
    List<Bake> getAllBakeList();

    @Query("SELECT * FROM BAKE_DATABASE WHERE bakeName = :bakeName")
    Bake getBakeName(String bakeName);

    @Query("DELETE FROM BAKE_DATABASE WHERE bakeName = :bakeName")
   void deleteBake(String bakeName);
}

