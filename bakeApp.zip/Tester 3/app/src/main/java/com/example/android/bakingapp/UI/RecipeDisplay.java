package com.example.android.bakingapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;

import java.util.List;

import butterknife.BindView;

public class RecipeDisplay extends AppCompatActivity implements RecipeNameFragment.onItemSelectedListener,
        DisplayRecipeFragment.OnRecipeDetailClickListener,DisplayRecipeFragment.OnIngredientClickListener{
    Bake bake;
    List<Steps> steps;
    public static final String BAKE_ID = "com.example.android.bakingapp.UI.extra.bakeID";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_recipes);
        if(savedInstanceState == null){
            bake = getIntent().getParcelableExtra(RecipeDisplay.BAKE_ID);
            steps = bake.getStepsBag();
            DisplayRecipeFragment.setBake(bake);
            DisplayRecipeFragment.setStepsbag(steps);
            FragmentManager recipeFragmentManager = getSupportFragmentManager();
            DisplayRecipeFragment displayRecipeFragment = new DisplayRecipeFragment();
            recipeFragmentManager.beginTransaction()
                    .add(R.id.recipe_display_container, displayRecipeFragment)
                    .commit();
        }
    }

    @Override
    public void onSelectItem(Bake bake) {
        if (bake != null){
            Log.v("rapha", bake.getName());
        }else {
            Log.v("rapha", "bake is empty ");
        }

    }

    @Override
    public void onIngredientClicked(Bake bake) {
        Intent intent = new Intent(this, DisplayIngredientList.class);
        intent.putExtra("BAKE",bake);
        startActivity(intent);


    }

    @Override
    public void onRecipeClicked(Steps steps, int position, List<Steps> stepsList) {
        Intent intent = new Intent(this, RecipeDetail.class);
                    intent.putExtra("STEP_DETAIL",steps);
                    intent.putExtra("STEP_POSITION",position);
                    startActivity(intent);

    }
}
