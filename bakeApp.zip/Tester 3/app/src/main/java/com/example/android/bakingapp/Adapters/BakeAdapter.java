package com.example.android.bakingapp.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.R;

import java.util.List;

public class BakeAdapter extends RecyclerView.Adapter<BakeAdapter.ViewHolder> {

    private OnItemClickLister onItemClickLister;

    public interface OnItemClickLister{
        void onClickedItem(Bake bake);
    }

    public void setOnItemClickLister(OnItemClickLister onItemClickLister){
        this.onItemClickLister = onItemClickLister;
    }


     List<Bake> bakeBag;
    private Context context;
    private TextView recipeNameView;

    public BakeAdapter(Context context, List<Bake> bakeBag){
        this.context = context;
        this.bakeBag = bakeBag;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
         ViewHolder(View itemView) {
            super(itemView);
            recipeNameView = itemView.findViewById(R.id.recipe_title);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (onItemClickLister!= null){
                onItemClickLister.onClickedItem(bakeBag.get(getAdapterPosition()));
            }
        }
    }

    @NonNull
    @Override
    public BakeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View contentView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout_for_recipe_name,parent,false);
        return new ViewHolder(contentView);
    }

    @Override
    public void onBindViewHolder(@NonNull BakeAdapter.ViewHolder holder, int position) {
        int i = holder.getAdapterPosition();
        final Bake bake = bakeBag.get(i);
        recipeNameView.setText(bake.getName());
    }

    @Override
    public int getItemCount() {
        return bakeBag.size();
    }

    public void updateBakeAdapter(List<Bake> updateBakeBag){
        bakeBag = updateBakeBag;
        notifyDataSetChanged();
    }

}
