package com.example.android.bakingapp.Model;


import android.os.Parcel;
import android.os.Parcelable;

public class Steps implements Parcelable {

    private String mId;
    private String mShortDescription;
    private String mDescription;
    private String mVideoURL;
    private String mThumbnailURL;

    public Steps(String id, String shortDescription,String description, String videoURL, String thumbnailURL){
        this.mId = id;
        this.mShortDescription = shortDescription;
        this.mDescription = description;
        this.mVideoURL = videoURL;
        this.mThumbnailURL = thumbnailURL;
    }


    public String getmId() {
        return mId;
    }

    public void setmId(String mId) {
        this.mId = mId;
    }

    public String getmShortDescription() {
        return mShortDescription;
    }

    public void setmShortDescription(String mShortDescription) {
        this.mShortDescription = mShortDescription;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public String getmVideoURL() {
        return mVideoURL;
    }

    public void setmVideoURL(String mVideoURL) {
        this.mVideoURL = mVideoURL;
    }

    public String getmThumbnailURL() {
        return mThumbnailURL;
    }

    public void setmThumbnailURL(String mThumbnailURL) {
        this.mThumbnailURL = mThumbnailURL;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.mId);
        parcel.writeString(this.mDescription);
        parcel.writeString(this.mShortDescription);
        parcel.writeString(this.mThumbnailURL);
        parcel.writeString(this.mVideoURL);

    }

    private Steps(Parcel in){
        this.mId = in.readString();
        this.mDescription = in.readString();
        this.mShortDescription = in.readString();
        this.mThumbnailURL = in.readString();
        this.mVideoURL = in.readString();
    }
    public static final Parcelable.Creator<Steps> CREATOR = new Parcelable.Creator<Steps>(){

        @Override
        public Steps createFromParcel(Parcel parcel) {
            return  new Steps(parcel);
        }

        @Override
        public Steps[] newArray(int i) {
            return new Steps[i];
        }
    };
}