package com.example.android.bakingapp.UI;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.android.bakingapp.Adapters.IngredientListAdapter;
import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class IngredientsFragment extends Fragment {
    @BindView(R.id.ingredient_list_recycler_view)
    RecyclerView ingredientListRecyclerView;

    static List<Ingredients> ingredientsListBag;
    IngredientListAdapter ingredientListAdapter;

    public IngredientsFragment(){ }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View viewRoot =  inflater.inflate(R.layout.ingredient_list_fragment,container,false);
        ButterKnife.bind(this,viewRoot);
        if (savedInstanceState != null){
            ingredientsListBag = savedInstanceState.getParcelableArrayList(getString(R.string.bake_list));
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        ingredientListRecyclerView.setLayoutManager(layoutManager);
        ingredientListAdapter = new IngredientListAdapter(getContext(),ingredientsListBag);
        ingredientListRecyclerView.setAdapter(ingredientListAdapter);
       return viewRoot;
    }

    public static  void setIngredientBag (List<Ingredients> ingredientBagBag){
        ingredientsListBag = ingredientBagBag;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.bake_list), (ArrayList<? extends Parcelable>) ingredientsListBag);
    }
}
