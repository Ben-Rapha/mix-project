package com.example.android.bakingapp.Repository.BakeWidget;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.R;
import com.example.android.bakingapp.Repository.BakeDao;
import com.example.android.bakingapp.Repository.BakeRoomDatabase;
import com.example.android.bakingapp.UI.RecipeDisplay;

import java.util.ArrayList;
import java.util.List;

public class ListWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new AppWidgetList(this.getApplicationContext());
    }
}
    class AppWidgetList implements RemoteViewsService.RemoteViewsFactory{
        private Bake bake;
        private List<Ingredients> ingredientsList = new ArrayList<>();
        private Context context;
        private int listSize = 0;

        AppWidgetList(Context context){
            this.context = context;
        }

        @Override
        public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            BakeRoomDatabase db = BakeRoomDatabase.getDatabase(context);
            BakeDao bakeDao = db.bakeDao();
            List<Bake> bakeListDataBase = bakeDao.getAllBakeList();
            if (!bakeListDataBase.isEmpty()) {
                if(listSize < bakeListDataBase.size()){
                    bake = bakeListDataBase.get(listSize);
                    ingredientsList = bake.getIngredientsBag();
                    listSize++;
                } else {
                    listSize = 0;
                }
            }
        }

        @Override
        public void onDestroy() {
        }

        @Override
        public int getCount() {
               return ingredientsList.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
          RemoteViews views = new RemoteViews(context.getPackageName(),R.layout.widget_row);
          views.setTextViewText(R.id.list_row_text_view,ingredientsList.get(position).getmIngredient());
          Bundle extras = new Bundle();
          extras.putParcelable(RecipeDisplay.BAKE_ID,bake);
          Intent fillIntent = new Intent();
          fillIntent.putExtras(extras);
          views.setOnClickFillInIntent(R.id.row_parent,fillIntent);
          return views;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }
    }

