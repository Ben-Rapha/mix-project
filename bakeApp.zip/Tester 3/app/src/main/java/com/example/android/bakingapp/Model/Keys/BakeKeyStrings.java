package com.example.android.bakingapp.Model.Keys;

public class BakeKeyStrings {

    private static final String BAKE_URL = "https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/baking.json";

    public static String getBakeUrl(){
        return BAKE_URL;
    }
}
