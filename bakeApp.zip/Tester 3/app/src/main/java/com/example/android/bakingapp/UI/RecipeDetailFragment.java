package com.example.android.bakingapp.UI;

import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecipeDetailFragment extends Fragment {
    @BindView(R.id.recipe_description)
    TextView recipeDescription;

    static Steps steps;
    static int position;

    private long playerPosition;
    private int currentWindow;
    private  boolean playWhenReady = true;
    private boolean resetPosition = true;

    @BindView(R.id.previous_button)
    Button previous;

    @BindView(R.id.next_button)
    Button next;

    static List<Steps>listBag;
    SimpleExoPlayer exoPlayer;

    @BindView(R.id.player_view)
    PlayerView playerView;

    @BindView(R.id.thumbNail)
    ImageView thumbNailImageView;

    Bitmap bitmap = null;

    public RecipeDetailFragment(){
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View viewRoot = inflater.inflate(R.layout.recipe_detail_fragment,container,false);
        ButterKnife.bind(this,viewRoot);
        if(savedInstanceState != null){
            steps = savedInstanceState.getParcelable("step");
            listBag = savedInstanceState.getParcelableArrayList(getString(R.string.bake_list));
            position = savedInstanceState.getInt("position");
            playWhenReady = savedInstanceState.getBoolean(getString(R.string.PLAY_WHEN_READY));
            currentWindow = savedInstanceState.getInt(getString(R.string.CURRENT_WINDOW));
            playerPosition = savedInstanceState.getLong(getString(R.string.PLAYER_POSITION));
            resetPosition = false;
        }
        recipeDescription.setText(steps.getmDescription());
        return viewRoot;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position++;
                if(listBag.size() != position){
                    steps = listBag.get(position);
                    resetPosition = true;
                    if (getUrl() != null){
                        playerInitializer(getUrl());
                    } else if (!steps.getmThumbnailURL().isEmpty()){
                        getThumbNail();
                    } else {
                        setNoImageAvailable();
                    }
                    recipeDescription.setText(steps.getmDescription());
                } else{
                    position = 0;
                    resetPosition = true;
                    steps = listBag.get(position);
                    if (getUrl() != null){
                        playerInitializer(getUrl());
                    } else if (!steps.getmThumbnailURL().isEmpty()){
                        getThumbNail();
                    } else {
                        setNoImageAvailable();
                    }
                    recipeDescription.setText(steps.getmDescription());
                }
            }
        });

        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                position--;
                if( 0 > position){
                    position = listBag.size() - 1;
                    steps = listBag.get(position);
                    resetPosition = true;
                    if (getUrl() != null){
                        playerInitializer(getUrl());
                    } else if (!steps.getmThumbnailURL().isEmpty()){
                        getThumbNail();
                    } else {
                        setNoImageAvailable();
                    }

                    recipeDescription.setText(steps.getmDescription());
                } else{
                    resetPosition =true;
                    steps = listBag.get(position);
                    if (getUrl() != null){
                        playerInitializer(getUrl());
                    } else if (!steps.getmThumbnailURL().isEmpty()){
                        getThumbNail();
                    } else {
                        setNoImageAvailable();
                    }
                    recipeDescription.setText(steps.getmDescription());
                }
            }
        });


    }

    public static void setStep(Steps step){
        steps = step;
    }

    public  static void getSetListBag(List<Steps> steps){
        listBag = steps;
    }

    public static void setPosition(int i ){
        position = i ;
    }

    public void playerInitializer(Uri uri){
        if(exoPlayer == null){
            exoPlayer = ExoPlayerFactory.newSimpleInstance(new DefaultRenderersFactory(getContext()),
                    new DefaultTrackSelector(),new DefaultLoadControl());
            playerView.setPlayer(exoPlayer);
            exoPlayer.setPlayWhenReady(playWhenReady);
            exoPlayer.seekTo(playerPosition);
        }
        MediaSource mediaSource = new ExtractorMediaSource.Factory(
                new DefaultHttpDataSourceFactory("recipe player")).createMediaSource(uri);
        exoPlayer.prepare(mediaSource,resetPosition,false); }

        private void releasePlayer(){
        if (exoPlayer != null){
            currentWindow = exoPlayer.getCurrentWindowIndex();
            playerPosition = exoPlayer.getCurrentPosition();
            playWhenReady = exoPlayer.getPlayWhenReady();
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getUrl() != null){
            playerInitializer(getUrl());
        } else if (!steps.getmThumbnailURL().isEmpty()){
            getThumbNail();
        } else {
            setNoImageAvailable();
        }

    }

    @Override
    public void onPause() {
        super.onPause();
        releasePlayer();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

// load thumbnail with picasso
private void setThumbNail(){
    Picasso.with(getContext()).load(steps.getmThumbnailURL()).
            fit().error(R.drawable.no_image_available).
            placeholder(R.drawable.no_image_available).
            into(thumbNailImageView);
}

//get a thumbnail if thumbnail contains a video url
    private  Bitmap retrieveThumbnailFrameFromVideo(String url) throws Throwable {
        Bitmap bitmap;
        MediaMetadataRetriever mediaMetadataRetriever = null;
        try {
            mediaMetadataRetriever = new MediaMetadataRetriever();
            if (Build.VERSION.SDK_INT >= 14)
                mediaMetadataRetriever.setDataSource(url, new HashMap<String, String>());
            else
                mediaMetadataRetriever.setDataSource(url);
            bitmap = mediaMetadataRetriever.getFrameAtTime(1, MediaMetadataRetriever.OPTION_CLOSEST);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Throwable("Exception in retrieveVideoFrameFromVideo(String url)" + e.getMessage());
        } finally {
            if (mediaMetadataRetriever != null) {
                mediaMetadataRetriever.release();
            }
        }
        return bitmap;
    }

    //check thumbnail url extension
private boolean validateThumbNail(String url){
        String fileExtension = MimeTypeMap.getFileExtensionFromUrl(url);
        return (fileExtension.equals("mp4"));
}

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.bake_list), (ArrayList<? extends Parcelable>) listBag);
        outState.putParcelable(getString(R.string.step),steps);
        outState.putInt(getString(R.string.position),position);
        outState.putInt(getString(R.string.CURRENT_WINDOW),currentWindow);
        outState.putLong(getString(R.string.PLAYER_POSITION),playerPosition);
        outState.putBoolean(getString(R.string.PLAY_WHEN_READY), playWhenReady);
    }

    //returns Uri to be played by  exo player
    private Uri getUrl(){
        if(!steps.getmVideoURL().isEmpty()){
            playerView.setVisibility(View.VISIBLE);
            thumbNailImageView.setVisibility(View.GONE);
            return Uri.parse(steps.getmVideoURL());
        }
        return null;
    }

    // set  image fall back if video url and thumbnail is not resolved
    private void setNoImageAvailable() {
            playerView.setVisibility(View.GONE);
            thumbNailImageView.setImageResource((R.drawable.no_image_available));
            thumbNailImageView.setVisibility(View.VISIBLE);
            releasePlayer();
    }

//try to retrieve  thumbnail if the video url is empty
    private void getThumbNail(){
        boolean validate = validateThumbNail(steps.getmThumbnailURL());
        if(validate){
            try {
                bitmap = retrieveThumbnailFrameFromVideo(steps.getmThumbnailURL());
            } catch (Throwable throwable) {
                throwable.printStackTrace();
            }
            if(bitmap != null){
                setThumbNail();
                releasePlayer();
            }
            setNoImageAvailable();

        }
    }

}
