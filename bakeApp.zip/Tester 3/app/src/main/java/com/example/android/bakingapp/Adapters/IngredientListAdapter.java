package com.example.android.bakingapp.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.bakingapp.Model.Ingredients;
import com.example.android.bakingapp.R;

import java.util.List;

public class IngredientListAdapter extends RecyclerView.Adapter<IngredientListAdapter.ViewHolder> {
    private Context context;
    private List<Ingredients> ingredientsBag;
    private TextView ingredentTextView;

    public IngredientListAdapter(Context context, List<Ingredients> ingredients){
        this.context = context;
        this.ingredientsBag = ingredients;
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        ViewHolder(View itemView) {
            super(itemView);
            ingredentTextView = itemView.findViewById(R.id.ingredient_list_text_view);
        }
    }

    @NonNull
    @Override
    public IngredientListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View contentView = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.ingrendient_list_row_layout,parent,false);
        return new IngredientListAdapter.ViewHolder(contentView);
    }

    @Override
    public void onBindViewHolder(@NonNull IngredientListAdapter.ViewHolder holder, int position) {
        int i = holder.getAdapterPosition();
        Ingredients ingredient = ingredientsBag.get(i);
        ingredentTextView.setText(ingredient.getmIngredient());

    }

    @Override
    public int getItemCount() {
        return ingredientsBag.size();
    }
}
