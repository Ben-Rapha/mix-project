package com.example.android.bakingapp.Repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import com.example.android.bakingapp.Model.Bake;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class BakeRepositoryDB {
    private BakeDao bakeDao;
    private LiveData<List<Bake>> allBakeData;
    private static Bake temp;

    public BakeRepositoryDB(Application application){
        BakeRoomDatabase db = BakeRoomDatabase.getDatabase(application);
        bakeDao = db.bakeDao();
        allBakeData = bakeDao.getAllBake();
    }

    public static class insertBakeAsyncTask extends AsyncTask<Bake,Void,Void>{
        private BakeDao mBakeAsyncTaskDao;
        insertBakeAsyncTask(BakeDao dao){
            mBakeAsyncTaskDao = dao;
        }
        @Override
        protected Void doInBackground(final Bake... movies) {
            mBakeAsyncTaskDao.insert(movies[0]);
            return null;
        }
    }
    public void insert(Bake bake){
        new insertBakeAsyncTask(bakeDao).execute(bake);
    }

    public static class getBakeIDAsyncTask extends AsyncTask<String,Void, Bake>{

        private BakeDao mBakeIDAsyncTask;
        getBakeIDAsyncTask(BakeDao dao){
            mBakeIDAsyncTask = dao; }

        @Override
        protected Bake doInBackground(String... movies) {
            temp = mBakeIDAsyncTask.getBakeName(movies[0]);
            return temp;
        }

    }
    public Bake getBakeName(String bakeName){
        AsyncTask movieData  = new getBakeIDAsyncTask(bakeDao).execute(bakeName);
        try {
            movieData.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return temp;
    }
}


