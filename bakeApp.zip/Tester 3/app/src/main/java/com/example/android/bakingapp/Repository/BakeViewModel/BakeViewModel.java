package com.example.android.bakingapp.Repository.BakeViewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.graphics.Movie;
import android.support.annotation.NonNull;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Repository.BakeRepositoryDB;
import com.example.android.bakingapp.Repository.BakeRepositoryNetwork;

import java.util.List;

public class BakeViewModel extends AndroidViewModel {

    private BakeRepositoryNetwork bakeRepositoryNetwork;
    private LiveData<List<Bake>> dataFromNetwork;
    private BakeRepositoryDB bakeRepositoryDB;

    public BakeViewModel(@NonNull Application application) {
        super(application);
        bakeRepositoryNetwork = new BakeRepositoryNetwork();
        bakeRepositoryDB = new BakeRepositoryDB(application);

    }
    public void getBakeData(){
        dataFromNetwork = bakeRepositoryNetwork.getDataFromNetwork();
    }

    public LiveData<List<Bake>> getDataFromViewModel(){
        return dataFromNetwork;
    }
    public void insert(Bake bake){
        bakeRepositoryDB.insert(bake);
    }

    public  Bake getBakeName(String bakeName){
        return  bakeRepositoryDB.getBakeName(bakeName);
    }
}

