package com.example.android.bakingapp.Repository;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.AsyncTask;

import com.example.android.bakingapp.Model.Bake;

import com.example.android.bakingapp.Model.Keys.BakeKeyStrings;
import com.example.android.bakingapp.Repository.BakeViewModel.BakeViewModel;

import java.io.IOException;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class BakeRepositoryNetwork  {

    public BakeRepositoryNetwork(){
    }

    private static MutableLiveData<List<Bake>> dataFromNetwork = new MutableLiveData<>();

    static List<Bake> bakeList;
    public static class BakeAsyncTask extends AsyncTask<String, Void , LiveData<List<Bake>>>{
    String bakeJsonStringData;

    OkHttpClient client = new OkHttpClient();
    @Override
    protected LiveData<List<Bake>> doInBackground(String... strings) {
        Request request = new Request.Builder().url(strings[0]).build();
        try {
            Response response = client.newCall(request).execute();
            bakeJsonStringData = response.body().string();
            bakeList = BakeJasonParser.parseBakeJson(bakeJsonStringData);
        } catch (IOException e) {
            e.printStackTrace();
        }
        dataFromNetwork.postValue(bakeList);
        return dataFromNetwork;
    }
}
    public MutableLiveData<List<Bake>> getDataFromNetwork(){
        new BakeAsyncTask().execute(BakeKeyStrings.getBakeUrl());
        return dataFromNetwork; }
}
