package com.example.android.bakingapp.UI;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.android.bakingapp.Adapters.DisplayRecipeAdapter;
import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;
import com.example.android.bakingapp.Repository.BakeViewModel.BakeViewModel;
import com.example.android.bakingapp.Repository.BakeWidget.BakeService;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DisplayRecipeFragment extends Fragment{
    @BindView(R.id.recycler_view_display_recipe)
    RecyclerView recyclerView;

    static List<Steps> mStepBag;

    @BindView(R.id.ingredient_text_view)
    TextView ingredientTextView;

    DisplayRecipeAdapter displayRecipeAdapter;
    static Bake bakeData;
    Bake temp;
    BakeViewModel bakeViewModel;

    public static final String BAKE_ID = "com.example.android.bakingapp.UI.extra.bakeID";

    private OnIngredientClickListener listener;

    public interface OnIngredientClickListener{
        void onIngredientClicked(Bake bake);
    }
    private OnRecipeDetailClickListener onRecipeDetailClickListener;

    public interface OnRecipeDetailClickListener{
        void onRecipeClicked(Steps steps,int position, List<Steps> stepsList);
    }

    public DisplayRecipeFragment(){
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View viewRoot = inflater.inflate(R.layout.display_recipes_fragement,container,false);
        ButterKnife.bind(this,viewRoot);
        if(savedInstanceState != null){
            mStepBag = savedInstanceState.getParcelableArrayList(getString(R.string.bake_list));
            bakeData = savedInstanceState.getParcelable("bake");
        }
        bakeViewModel = ViewModelProviders.of(this).get(BakeViewModel.class);
        temp = bakeViewModel.getBakeName(bakeData.getName());
        ingredientTextView.setText(R.string.ingredients);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        displayRecipeAdapter = new DisplayRecipeAdapter(getContext(), mStepBag);
        displayRecipeAdapter.setOnRecipeItemSelect(new DisplayRecipeAdapter.OnRecipeItemSelect() {

            @Override
            public void onItemSelect(Steps steps, int position, List<Steps> stepsList) {
                onRecipeDetailClickListener.onRecipeClicked(steps,position,stepsList);
            }
        });
        recyclerView.setAdapter(displayRecipeAdapter);

        onIngredientClick();

        if(temp == null){
            bakeViewModel.insert(bakeData);
            BakeService.startActionUpdateBakeWidget(getContext());
        } else{
            Log.v("bell", "already inserted");
        }
        return viewRoot;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof OnIngredientClickListener){
            listener = (OnIngredientClickListener) context;
            onRecipeDetailClickListener = (OnRecipeDetailClickListener) context;
        } else {
            throw new ClassCastException("must implement onItemSelectedListener");
        }
    }

    public static  void setStepsbag (List<Steps> stepsBag){
        mStepBag = stepsBag;
    }

    public static void setBake(Bake bake){
        bakeData = bake;
    }

    public  void onIngredientClick(){
        ingredientTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onIngredientClicked(bakeData);
            }
        });
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(getString(R.string.bake_list), (ArrayList<? extends Parcelable>) mStepBag);
        outState.putParcelable("bake",bakeData);
    }
}


