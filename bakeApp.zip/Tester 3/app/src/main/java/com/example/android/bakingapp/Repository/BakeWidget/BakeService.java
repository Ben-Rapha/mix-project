package com.example.android.bakingapp.Repository.BakeWidget;

import android.app.Application;
import android.app.IntentService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.android.bakingapp.Model.Bake;
import com.example.android.bakingapp.R;
import com.example.android.bakingapp.Repository.BakeDao;
import com.example.android.bakingapp.Repository.BakeRoomDatabase;

import java.util.List;

public class BakeService extends IntentService{
    public static final String ACTION_UPDATE_INGREDIENT_WIDGET =
            "com.example.android.bakingapp.Repository.BakeWidget.action.update_bake_widget";

    public BakeService() {
        super("BakeService");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        if(intent != null){
            final String action = intent.getAction();
            if (ACTION_UPDATE_INGREDIENT_WIDGET.equals(action)){
                actionUpdateBakeWidget();
            }
        }

    }
    private  void actionUpdateBakeWidget(){
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
        int [] appWidgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(this,BakeAppWidgetProvider.class));
        BakeAppWidgetProvider.updateBakeWidget(this,appWidgetManager,appWidgetIds);
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetIds,R.id.database_list);
    }
    public static void startActionUpdateBakeWidget(Context context){
        Intent intent  = new Intent (context,BakeService.class);
        intent.setAction(ACTION_UPDATE_INGREDIENT_WIDGET);
        context.startService(intent);
    }

}
