package com.example.android.bakingapp.UI;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.android.bakingapp.Adapters.DisplayRecipeAdapter;
import com.example.android.bakingapp.Model.Steps;
import com.example.android.bakingapp.R;

import java.util.List;


public class RecipeDetail extends AppCompatActivity implements  DisplayRecipeFragment.OnRecipeDetailClickListener{

    Steps step;
    List<Steps> stepsList;
    int position;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_detail_activity_layout);
        if (savedInstanceState == null){
            step = getIntent().getParcelableExtra("STEP_DETAIL");
            position = getIntent().getIntExtra("STEP_POSITION",0);
            RecipeDetailFragment.setPosition(position);
            stepsList = DisplayRecipeAdapter.sendStepBag();
            if(stepsList != null){
                RecipeDetailFragment.getSetListBag(stepsList);
            }
            RecipeDetailFragment.setStep(step);
            FragmentManager fragmentManager = getSupportFragmentManager();
            RecipeDetailFragment recipeDetailFragment = new RecipeDetailFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.recipe_detail_container,recipeDetailFragment)
                    .commit();
        }
    }

    @Override
    public void onRecipeClicked(Steps steps, int position, List<Steps> stepsList) {

    }
}
